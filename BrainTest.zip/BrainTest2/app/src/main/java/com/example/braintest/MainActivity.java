package com.example.braintest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button start;
    int correctPosition;
    ArrayList<Integer> list = new ArrayList<Integer>();
    TextView answer;
    TextView question;
    TextView score;
    Button first;
    Button second;
    Button third;
    Button fourth;
    Button play;
    int marks = 0;
    int totalQues = 0;
    TextView timer;
    ConstraintLayout main;

    public void generateQues()
    {
        list.clear();
        Random rand = new Random();
        correctPosition = rand.nextInt(3);
        int a = rand.nextInt(21);
        int b = rand.nextInt(21);
        question.setText(Integer.toString(a) + " + " + Integer.toString(b));
        int c = rand.nextInt(41);
        int incorrectAns;
        for(int i=0; i<4; i++)
        {
            if(i == correctPosition)
            {
                list.add(a+b);
            }
            else
            {
                incorrectAns = rand.nextInt(41);
                while (incorrectAns == a+b)
                {
                    incorrectAns = rand.nextInt(41);
                }
                list.add(incorrectAns);
            }
        }
        first.setText(Integer.toString(list.get(0)));
        second.setText(Integer.toString(list.get(1)));
        third.setText(Integer.toString(list.get(2)));
        fourth.setText(Integer.toString(list.get(3)));
    }

    public void chooseAns(View view)
    {
        if(view.getTag().toString().equals(Integer.toString(correctPosition)))
        {
            marks++;
            answer.setText("Correct");
        }
        else
            answer.setText("Wrong");
        answer.setVisibility(View.VISIBLE);
        totalQues++;
        score.setText(Integer.toString(marks) + "/" + Integer.toString(totalQues));
        generateQues();
    }

    public void checkTiming()
    {
        new CountDownTimer(30100, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timer.setText(String.valueOf(millisUntilFinished/1000) + "s");
            }

            @Override
            public void onFinish() {
                timer.setText("0s");
                answer.setVisibility(View.VISIBLE);
                answer.setText("Your score is " + Integer.toString(marks) + "/" + Integer.toString(totalQues));
                play.setVisibility(View.VISIBLE);
            }
        }.start();
    }

    public void startButton(View view)
    {
        start.setVisibility(View.INVISIBLE);
        main.setVisibility(View.VISIBLE);
    }

    public void PlayAgain(View view)
    {
        answer.setVisibility(View.INVISIBLE);
        play.setVisibility(View.INVISIBLE);
        checkTiming();
        generateQues();
        timer.setText("30s");
        score.setText("0/0");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        start = findViewById(R.id.start);
        answer = findViewById(R.id.check);
        question = findViewById(R.id.ques);
        first = findViewById(R.id.first);
        second = findViewById(R.id.second);
        third = findViewById(R.id.third);
        fourth = findViewById(R.id.fourth);
        score = findViewById(R.id.answers);
        play = findViewById(R.id.play);
        timer = findViewById(R.id.timer);
        main = findViewById(R.id.mainGame);

        generateQues();
        checkTiming();
    }
}